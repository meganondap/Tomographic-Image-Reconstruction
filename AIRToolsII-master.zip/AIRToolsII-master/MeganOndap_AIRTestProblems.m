%% Fan Curved Tomo

N = 64; % Set image size (number of pixels per side)
[A, b, x, theta, p, R, d] = fancurvedtomo(N);

% visualize true image
figure;
subplot(1,2,1)
imagesc(reshape(x, N, N));
colormap gray;
axis image;
title('True Phantom Image');

% reconstruct using least squares
x_rec = A \ b; % If A is a matrix
subplot(1,2,2)
imagesc(reshape(x_rec, N, N));
colormap gray;
axis image;
title('Reconstructed Image');
%% show ray display of fan curved tomo
[A, b, x, theta, p, R, d] = fancurvedtomo(N, theta, p, R, d, 0.2);
%% Fan linear tomo

N = 64;                % Image size
theta = 0:1:179;       % Projection angles (degrees)
p = 90;                % Number of rays per angle
R = 2;                 % Source distance scaling
dw = 2.5;              % Detector width
sd = 3;                % Source-to-detector distance

[A, b, x, theta, p, R, dw, sd] = fanlineartomo(N, theta, p, R, dw, sd);

% visualize the phantom
figure;
subplot(1,2,1)
imagesc(reshape(x, N, N));
colormap gray;
axis image;
title('True Phantom Image');

%reconstruct the image
subplot(1,2,2)
x_rec = A \ b;
imagesc(reshape(x_rec, N, N));
colormap gray;
axis image;
title('Reconstructed Image');

%% Display ray geometry
[A, b, x, theta, p, R, dw, sd] = fanlineartomo(N, theta, p, R, dw, sd, 0.2);

%% Parallel tomo 

N = 64;                % Image size
theta = 0:1:179;       % Projection angles (degrees)
p = 90;                % Number of parallel rays per angle
d = p - 1;             % Total width covered by rays

[A, b, x, theta, p, d] = paralleltomo(N, theta, p, d);

figure;
subplot(1,2,1)
imagesc(reshape(x, N, N));
colormap gray;
axis image;
title('True Phantom Image');

subplot(1,2,2)
x_rec = A \ b;
imagesc(reshape(x_rec, N, N));
colormap gray;
axis image;
title('Reconstructed Image');

%% Display Ray geometry
[A, b, x, theta, p, d] = paralleltomo(N, theta, p, d, 0.2);

%% Seismictomo
N = 64;    % Image size
s = 40;    % Number of sources on right boundary
p = 80;    % Number of receivers on left/top boundaries

[A, b, x, s, p] = seismictomo(N, s, p);

figure;
subplot(1,2,1)
imagesc(reshape(x, N, N));
colormap gray;
axis image;
title('True Subsurface Phantom');

subplot(1,2,2)
x_rec = A \ b;
imagesc(reshape(x_rec, N, N));
colormap gray;
axis image;
title('Reconstructed Subsurface Image');
%% Display ray geometry
[A, b, x, s, p] = seismictomo(N, s, p, 0.2);
%% Seismic wave tomo
N = 64;     % Image size
s = 40;     % Number of sources on right boundary
p = 80;     % Number of receivers on left/top boundaries
omega = 15; % Dominant wave frequency

[A, b, x, s, p, omega] = seismicwavetomo(N, s, p, omega);

figure;
subplot(1,2,1);
imagesc(reshape(x, N, N));
colormap gray;
axis image;
title('True Subsurface Phantom');

subplot(1,2,2)
x_rec = A \ b;
imagesc(reshape(x_rec, N, N));
colormap gray;
axis image;
title('Reconstructed Subsurface Image');
%% Display sensitivity kernels
[A, b, x, s, p, omega] = seismicwavetomo(N, s, p, omega, 0.2);
%% Show_tomo
[A, b, x] = paralleltomo(64); % Create a tomographic problem
show_tomo(A);                 % Show all measurement geometries
show_tomo(A, 1:10, 0.5);      % Show first 10 rays, pause 0.5s between each

%% Spherical tomo
N = 64;                   % Image size
angles = 0:10:350;        % Angles for circle centers (degrees)
numCircles = 40;          % Number of concentric circles per center

[A, b, x, angles, numCircles] = sphericaltomo(N, angles, numCircles);

figure;
subplot(1,2,1)
imagesc(reshape(x, N, N));
colormap gray;
axis image;
title('True Phantom Image');

subplot(1,2,2)
x_rec = A \ b;
x_rec = lsqr(A, b);
imagesc(reshape(x_rec, N, N));
colormap gray;
axis image;
title('Reconstructed Image with LSQR');

%% Display ray geometry
[A, b, x, angles, numCircles] = sphericaltomo(N, angles, numCircles, 0.2);



