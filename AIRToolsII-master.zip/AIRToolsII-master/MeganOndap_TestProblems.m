%% Fan Curved Tomo

N = 64; % Set image size (number of pixels per side)
[A, b, x, theta, p, R, d] = fancurvedtomo(N);

% visualize true image
figure;
subplot(1,2,1)
imagesc(reshape(x, N, N));
colormap gray;
axis image;
title('True Phantom Image');

% reconstruct using least squares
x_rec = A \ b; % If A is a matrix
subplot(1,2,2)
imagesc(reshape(x_rec, N, N));
colormap gray;
axis image;
title('Reconstructed Image');
%% show ray display of fan curved tomo
[A, b, x, theta, p, R, d] = fancurvedtomo(N, theta, p, R, d, 0.2);
%%
